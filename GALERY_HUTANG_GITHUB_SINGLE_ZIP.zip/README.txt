HUTANG Android WebView project
1. Upload the contents of this ZIP to a GitHub repository.
2. GitHub Actions workflow is included at .github/workflows/build.yml.
3. Run Actions > Build HUTANG APK, or push to main.
4. Download artifact named HUTANG-debug-apk.

Launcher icon is intentionally left as Android's default for this test build.
When the user provides the final PNG icon, replace launcher resources while preserving the PNG's original transparent shape (no circular crop/mask).
The current app HTML is app/src/main/assets/index.html.
